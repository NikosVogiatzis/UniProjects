package com.example.tipcalculate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;

public class CalculateTipsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_tips);

        CheckBox morning_shift = findViewById(R.id.morning_shift);
        CheckBox night_shift = findViewById(R.id.night_shift);


//        Only one check box should be checked
        morning_shift.setOnClickListener(v-> night_shift.setChecked(false));
        night_shift.setOnClickListener(v-> morning_shift.setChecked(false));
    }
}