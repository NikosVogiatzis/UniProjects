package com.example.tipcalculate;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperStaff extends SQLiteOpenHelper {
    public static final String DBNAME = "Staff.db";
    public static final String COLUMN_ID = "_id";


    public DBHelperStaff(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table staff(COLUMN_ID INTEGER PRIMARY KEY, company_id TEXT, name TEXT, role TEXT, tip_points INTEGER, shift TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertStaff(long companyId,String name,String role, Integer tip_points, String shift)
    {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("company_id", companyId);
        contentValues.put("name", name);
        contentValues.put("role", role);
        contentValues.put("tip_points", tip_points);
        contentValues.put("shift", shift);
        long result = MyDB.insert("staff", null, contentValues);
        return result != -1;

    }
}
