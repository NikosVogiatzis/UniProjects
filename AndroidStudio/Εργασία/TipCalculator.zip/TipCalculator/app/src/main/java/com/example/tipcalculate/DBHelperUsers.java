package com.example.tipcalculate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperUsers extends SQLiteOpenHelper {

    public static final String DBNAME = "Users.db";
    public static final String COLUMN_ID = "_id";

    public DBHelperUsers(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(COLUMN_ID INTEGER, company TEXT primary key, password TEXT, email TEXT, location TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
        MyDB.execSQL("drop Table if exists users");
    }

    public long insertData(String company, String password, String email, String location)
    {
        long companyId;
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("company", company);
        contentValues.put("password", password);
        contentValues.put("email", email);
        contentValues.put("location", location);
        System.out.println(contentValues.size());

        companyId = MyDB.insert("users", null, contentValues);
        return companyId;

    }

//    Vlepei an to company name uparxei hdh sto db
    public boolean checkCompanyName(String company)
    {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where company = ? ",
                new String[] {company});
        return cursor.getCount() > 0;
    }


//    Ελέγχει το συνδυασμό ώστε να γίνει το login
    public boolean checkCompanyPassword(String company, String password)
    {
        SQLiteDatabase MyDB = getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where company = ? and password =  ?",
                new String[] {company, password});
        return cursor.getCount() > 0;
    }

}
