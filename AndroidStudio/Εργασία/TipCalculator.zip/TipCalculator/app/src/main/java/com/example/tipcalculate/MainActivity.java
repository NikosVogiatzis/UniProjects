package com.example.tipcalculate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public EditText company_name;
    public EditText password;
    DBHelperUsers DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        company_name = (EditText) findViewById(R.id.company_input_edit);
        password = (EditText) findViewById(R.id.password_edit_text);
        DB = new DBHelperUsers(this);

        Button button_register = findViewById(R.id.Register);
        ButtonRegisterOnClick(button_register, DB);
        Button button_login = findViewById(R.id.Login);
        ButtonLoginOnClick(button_login, DB);




// Set an OnClickListener for the button

    }

    public void ButtonRegisterOnClick(Button button, DBHelperUsers DB)
    {
        button.setOnClickListener(v -> {
            // Create an Intent to navigate to the new activity (MainAppActivity)

            Intent intent = new Intent(MainActivity.this, register_activity.class);

            // Start the new activity
            startActivity(intent);
        });
    }

    public void ButtonLoginOnClick(Button button, DBHelperUsers DB)
    {
        button.setOnClickListener(v -> {
            // Create an Intent to navigate to the new activity (MainAppActivity)
            String company = company_name.getText().toString();
            String _password = password.getText().toString();

            if (company.equals("") || _password.equals("")) {
                Toast.makeText(MainActivity.this, "Enter all the fields", Toast.LENGTH_SHORT).show();
            }
            else {
                if(DB.checkCompanyPassword(company, _password))
                {
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                    // Start the new activity
                    intent.putExtra("CompanyName", company);
                    startActivity(intent);
                }
                else
                    Toast.makeText(MainActivity.this, "Wrong credentials", Toast.LENGTH_SHORT).show();
            }

        });
    }

}