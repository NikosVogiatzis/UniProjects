package com.example.tipcalculate;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

//        Το activity αυτό καλείται μόνο από το main_activity με intent οπότε παίρνω την παράμετρο
//        και τη θέτω ως τιμη στο TextView που κρατά το όνομα της επιχείρησης
        TextView comp_name = findViewById(R.id.companyName);
        comp_name.setText(getIntent().getStringExtra("CompanyName"));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog_logout, null);

        builder.setView(dialogView)
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();

//                  Προσωρινη λυση να ξανα ξεκινα το activity αν και δεν το θελουμε
                    startActivity(new Intent(MainActivity2.this, MainActivity2.class));
                })
                .setPositiveButton("OK", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                    // Start the new activity
                    dialog.dismiss();
                    startActivity(intent);
                });

        Button button_logout = findViewById(R.id.logout_btn);
        button_logout.setOnClickListener(v->{
            dialog = builder.create();
            dialog.show();
        });

        Button button_calculate_tips = findViewById(R.id.calculate_tips);
        CalculateTipsOnClick(button_calculate_tips);
    }

    public void CalculateTipsOnClick(Button button)
    {
        button.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity2.this, CalculateTipsActivity.class);
            startActivity(intent);
        });

    }
}