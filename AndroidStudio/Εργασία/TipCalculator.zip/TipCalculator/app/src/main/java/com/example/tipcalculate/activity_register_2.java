package com.example.tipcalculate;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class activity_register_2 extends AppCompatActivity {

    DBHelperUsers UsersDB;
    DBHelperStaff StaffDB;
    String comp_name;
    String password;
    String email;
    String location;
    AlertDialog dialog;

    String checked_radio_button;

    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> role = new ArrayList<>();
    ArrayList<Integer> tip_points = new ArrayList<>();
    ArrayList<String> shift = new ArrayList<>();

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);


//        Set up DB's
        UsersDB = new DBHelperUsers(this);
        StaffDB = new DBHelperStaff(this);

//        Set up DB's
//        ImageButton του ίδιου Activity
        ImageButton assistant_waiter_button = findViewById(R.id.assistant_waiter_btn);
        ImageButton waiter_button = findViewById(R.id.waiter_btn);
        ImageButton chef_button = findViewById(R.id.chef_btn);
        ImageButton bar_button = findViewById(R.id.bar_btn);
        ImageButton reception_button = findViewById(R.id.reception_btn);
        ImageButton cashier_button = findViewById(R.id.cashier_btn);
        ImageButton dishwasher_button = findViewById(R.id.diswasher_btn);
//        ImageButton του ίδιου Activity

        Button save_button = findViewById(R.id.Save);

//        Intent variables
        comp_name = getIntent().getStringExtra("company_name");
        password = getIntent().getStringExtra("password");
        email = getIntent().getStringExtra("email");
        location = getIntent().getStringExtra("location");


//        Intent variables

//        ---------> DIALOG <-----------
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog, null);
        TextView textView = dialogView.findViewById(R.id.dialog_text_view);
        EditText employee_name = dialogView.findViewById(R.id.employee_name);
        EditText employee_points = dialogView.findViewById(R.id.emplyee_points);
        RadioButton morning_shift = dialogView.findViewById(R.id.morning_check_box);
        RadioButton night_shift = dialogView.findViewById(R.id.night_check_box);
        Button add = dialogView.findViewById(R.id.add);
//         ---------> DIALOG <-----------


        builder1.setView(dialogView);
        dialog = builder1.create();

        waiter_button.setOnClickListener(v -> {
            textView.setText("Waiter");
            dialog.show();
        });

        assistant_waiter_button.setOnClickListener(v -> {
            textView.setText("Assistant Waiter");
            dialog.show();
        });

        chef_button.setOnClickListener(v -> {
            textView.setText("Chef");
            dialog.show();
        });
        bar_button.setOnClickListener(v -> {
            textView.setText("Bar/Barista");
            dialog.show();
        });
        cashier_button.setOnClickListener(v -> {
            textView.setText("Cashier");
            dialog.show();
        });
        reception_button.setOnClickListener(v -> {
            textView.setText("Reception");
            dialog.show();
        });
        dishwasher_button.setOnClickListener(v -> {
            textView.setText("Dishwasher");
            dialog.show();
        });

        add.setOnClickListener(v -> {
            if( employee_name.getText().toString().equals("") || employee_points.getText().toString().equals("")
                    || (!morning_shift.isChecked() && !night_shift.isChecked())) {
                Toast.makeText(activity_register_2.this, "Fill Up All Data", Toast.LENGTH_SHORT).show(); }
            else{
                if (morning_shift.isChecked())
                    checked_radio_button = "morning";
                else
                    checked_radio_button = "night";
                names.add(employee_name.getText().toString());
                role.add(textView.getText().toString());
                tip_points.add(Integer.parseInt(employee_points.getText().toString()));
                shift.add(checked_radio_button);
                dialog.dismiss();
                employee_name.setText("");
                employee_points.setText(""); }
        });

        save_button.setOnClickListener(v->{

//            This is for Debug only
//            for(int i= 0; i<names.size();i++) {
//                Toast.makeText(activity_register_2.this, names.get(i), Toast.LENGTH_SHORT).show();
//                Toast.makeText(activity_register_2.this, role.get(i), Toast.LENGTH_SHORT).show();
//                Toast.makeText(activity_register_2.this, tip_points.get(i).toString(), Toast.LENGTH_SHORT).show();
//                Toast.makeText(activity_register_2.this, shift.get(i), Toast.LENGTH_SHORT).show();
//            }


            long company_id = UsersDB.insertData(comp_name, password, email, location);

            Toast.makeText(activity_register_2.this, "Succesfull Users insert", Toast.LENGTH_SHORT).show();

            for (int i = 0; i<names.size();i++) {
                boolean isInserted = StaffDB.insertStaff(
                        company_id,
                        names.get(i),
                        role.get(i),
                        tip_points.get(i),
                        shift.get(i)

                );
                if (!isInserted) {
                    Toast.makeText(activity_register_2.this, "GAMITHIKAN OLA", Toast.LENGTH_SHORT).show();
                    // Handle insertion failure
                    // You might want to consider rolling back the previously inserted company data
                }
            }

            Intent intent = new Intent(activity_register_2.this, MainActivity.class);
            startActivity(intent);
        });
    }
}