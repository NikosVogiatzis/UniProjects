package com.example.tipcalculate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.UnderlineSpan;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class register_activity extends AppCompatActivity {

    public EditText company;
    public EditText password_text;
    public EditText email_text;
    public EditText location_text;
    DBHelperUsers DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        company = (EditText) findViewById(R.id.company_text_register);
        password_text = (EditText) findViewById(R.id.password_edit_register);
        email_text = (EditText) findViewById(R.id.email_edit_text);
        location_text = (EditText) findViewById(R.id.location_edit_text);
        DB = new DBHelperUsers(this);



//        Listener for Next button
        Button next_page = findViewById(R.id.next);
        NextButtonOnClick(next_page, DB);

//        Listener for Home button
        Button home_button = findViewById(R.id.home_button);
        HomeButtonOnClick(home_button);

//        Underline Account text view
        TextView text_view = findViewById(R.id.account);
        SpannableString ss = new SpannableString("Account");
        ss.setSpan(new UnderlineSpan(), 0, 7, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text_view.setText(ss);
    }

    public void NextButtonOnClick(Button button, DBHelperUsers DB)
    {
        button.setOnClickListener(v -> {
            // Create an Intent to navigate to the new activity (MainAppActivity)

            String company_name = company.getText().toString();
            String password = password_text.getText().toString();
            String email = email_text.getText().toString();
            String location = location_text.getText().toString();


            if (company_name.equals("") || password.equals("") || email.equals("") || location.equals(""))
            {
                Toast.makeText(register_activity.this, "Fill Up All Fields to Continue", Toast.LENGTH_SHORT).show();
            }
            else {
                if (DB.checkCompanyName(company_name)) {
                    Toast.makeText(register_activity.this, "This Company Name Already Exists", Toast.LENGTH_SHORT).show();
                }
                else {


                    Intent intent = new Intent(register_activity.this, activity_register_2.class);
                    intent.putExtra("company_name", company_name);
                    intent.putExtra("password", password);
                    intent.putExtra("email", email);
                    intent.putExtra("location", location);
                    startActivity(intent);
                }
            }
        });
    }

    public void HomeButtonOnClick(Button button)
    {
        button.setOnClickListener(v-> {
            Intent intent = new Intent(register_activity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}